﻿using Avalonia.Controls;

namespace AvaloniaApplicationMVVM.Views;

public partial class MainView : Window
{
    public MainView()
    {
        InitializeComponent();
    }
}
