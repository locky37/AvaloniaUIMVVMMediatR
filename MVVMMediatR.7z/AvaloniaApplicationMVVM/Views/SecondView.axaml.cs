using Avalonia.Controls;

namespace AvaloniaApplicationMVVM;

public partial class SecondView : Window
{
    public SecondView()
    {
        InitializeComponent();
    }
}