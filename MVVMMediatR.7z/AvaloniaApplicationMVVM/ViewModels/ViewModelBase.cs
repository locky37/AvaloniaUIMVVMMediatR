﻿using AvaloniaApplicationMVVM.Notifications;
using CommunityToolkit.Mvvm.ComponentModel;
using MediatR;

namespace AvaloniaApplicationMVVM.ViewModels;

public class ViewModelBase : ObservableObject
{
}
